export default function CanvasFeatures() {
  return (
    <div className="framer-mpaozn" data-framer-name="Canvas" id="canvas">
      <div
        className="framer-1jenw7h"
        data-framer-name="Canvas Heading"
        data-framer-component-type="RichTextContainer"
      >
        <h2 className="framer-text framer-styles-preset-1fpslbf" dir="auto">
          Less friction. More imagination.
        </h2>
      </div>
      <div className="framer-5znfcp" data-framer-name="Feature Grid">
        <div className="framer-bqw6ti" data-border="true" data-framer-name="Infinite Canvas">
          <div className="framer-125sgvb" data-framer-component-type="RichTextContainer">
            <p
              dir="auto"
              style={{
                "--framer-font-size": "24px",
                "--framer-font-weight": "900",
                "--framer-text-color": "#F4F4F4",
              }}
              className="framer-text"
            >
              Room for every idea.
            </p>
          </div>
          <div className="framer-1r6c2aj" data-framer-component-type="RichTextContainer">
            <p className="framer-text framer-styles-preset-1jfw6q" dir="auto">
              An infinite canvas for images, references, and the connections that spark something
              new.
            </p>
          </div>
        </div>
        <div className="framer-8hdxec" data-border="true" data-framer-name="Cloud Sync">
          <div className="framer-1cqiaf5" data-framer-component-type="RichTextContainer">
            <p
              dir="auto"
              style={{
                "--framer-font-size": "24px",
                "--framer-font-weight": "900",
                "--framer-text-color": "#F4F4F4",
              }}
              className="framer-text"
            >
              Pick up anywhere.
            </p>
          </div>
          <div className="framer-183b4a3" data-framer-component-type="RichTextContainer">
            <p className="framer-text framer-styles-preset-1jfw6q" dir="auto">
              Cloud sync keeps your boards together, so your inspiration is ready when you are.
            </p>
          </div>
        </div>
        <div className="framer-o8sddf" data-border="true" data-framer-name="Canvas Elements">
          <div className="framer-11206tf" data-framer-component-type="RichTextContainer">
            <p
              dir="auto"
              style={{
                "--framer-font-size": "24px",
                "--framer-font-weight": "900",
                "--framer-text-color": "#F4F4F4",
              }}
              className="framer-text"
            >
              Make it your own.
            </p>
          </div>
          <div className="framer-1xh0i91" data-framer-component-type="RichTextContainer">
            <p className="framer-text framer-styles-preset-1jfw6q" dir="auto">
              Capable canvas elements give every moodboard and brainstorm the freedom it deserves.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
