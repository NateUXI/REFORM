import MountainToStudioScene from "./MountainToStudioScene";

export default function CreateAnywhere() {
  return (
    <div className="framer-l1kme2" data-framer-name="Create Anywhere" id="anywhere">
      <MountainToStudioScene />
      <div className="framer-1jo9d8r" data-framer-name="Anywhere Copy">
        <div className="framer-hj9spr" data-framer-component-type="RichTextContainer">
          <h2 className="framer-text framer-styles-preset-1fpslbf" dir="auto">
            From a mountain top to your studio.
          </h2>
        </div>
        <div className="framer-iknskn" data-framer-component-type="RichTextContainer">
          <p className="framer-text framer-styles-preset-1jfw6q" dir="auto">
            Great ideas don’t need to wait until you’re back in the studio. Collect, brainstorm, and
            create on the go. With REFORM your whole creative world at your fingertips.
          </p>
        </div>
        <div className="framer-10dwzq8" data-framer-component-type="RichTextContainer">
          <p className="framer-text framer-styles-preset-1qscw88" dir="auto">
            EVERY CANVAS. EVERYWHERE YOU GO.
          </p>
        </div>
      </div>
    </div>
  );
}
