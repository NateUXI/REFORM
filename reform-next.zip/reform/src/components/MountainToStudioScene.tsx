"use client";

import { useEffect, useRef, useState } from "react";
import BackgroundImage from "./BackgroundImage";
import { images } from "@/lib/assets";

/**
 * The "From a mountain top to your studio" picture. It starts on the mountain
 * and cross-fades to the studio photo the first time it scrolls into view.
 * (The fade itself is styled in globals.css via `data-revealed`.)
 */
export default function MountainToStudioScene() {
  const ref = useRef<HTMLDivElement>(null);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true);
          observer.disconnect();
        }
      },
      { threshold: 0.6 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className="framer-bkvrnn" data-framer-name="Mountain to Studio Scene">
      <BackgroundImage image={images.mountain} lazy />
      <div className="framer-1x2vofi" data-framer-name="Studio Background" data-revealed={revealed}>
        <BackgroundImage image={images.studio} lazy />
      </div>
      <div className="framer-eono7b" data-framer-name="Scene Shade" />
      <div className="framer-1uasw80" data-framer-name="Board Preview">
        <div className="framer-1uqnxu0" data-framer-name="Scene Login Phone">
          <BackgroundImage image={images.loginPhone} />
        </div>
      </div>
    </div>
  );
}
