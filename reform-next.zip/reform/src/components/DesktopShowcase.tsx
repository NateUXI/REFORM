import DesktopCarousel from "./DesktopCarousel";

export default function DesktopShowcase() {
  return (
    <>
      <div className="framer-1h9pl6d" data-framer-name="Desktop Showcase" id="desktop">
        <div
          className="framer-1y4iga7"
          data-framer-name="Desktop Heading"
          data-framer-component-type="RichTextContainer"
        >
          <h2 className="framer-text framer-styles-preset-1fpslbf" dir="auto">
            <span
              data-text-fill="true"
              style={{
                backgroundImage:
                  "linear-gradient(110deg, rgb(51, 161, 208) 0%, rgb(51, 164, 112) 100%)",
              }}
              className="framer-text"
            >
              A bigger space for your next big idea.
            </span>
          </h2>
        </div>
        <div className="framer-1mam3u4" data-framer-component-type="RichTextContainer">
          <p className="framer-text framer-styles-preset-1jfw6q" dir="auto">
            Your boards, at home on desktop. Keep collecting and creating with room to see the whole
            picture.
          </p>
        </div>
      </div>
      <DesktopCarousel />
    </>
  );
}
